/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arboles;

import Excepciones.OrdenInvalidoExcepcion;
import java.util.Stack;

/**
 *
 * @author jairo
 */
public class ArbolB <K extends Comparable<K>,V>
             extends ArbolMViasBusqueda<K, V> {
    
    private final int nroMaxDeClaves;
    private final int nroMimDeClaves;
    private final int nroMinDeHijos;
    
    public ArbolB(){
    super();
    this.nroMaxDeClaves=2;
    this.nroMimDeClaves=1;
    this.nroMinDeHijos=2;
    }
    //La raiz puede romper la regla del numero minimo de datos
    public ArbolB(int orden) throws OrdenInvalidoExcepcion{
        super(orden); //Referencia a algo de la clase padre;
        this.nroMaxDeClaves= super.orden-1; //
        this.nroMimDeClaves= this.nroMaxDeClaves/2; //2
        this.nroMinDeHijos= this.nroMimDeClaves+1; //3
    } 
    
    /**
     *
     * @param claveAInsertar
     * @param valorAsociado
     */
    @Override
    public void insertar(K claveAInsertar, V valorAsociado) {
        if (claveAInsertar == null) {
            throw new IllegalArgumentException("Clave no puede ser nula" + "vacia");
        }

        if (valorAsociado == null) {
            throw new IllegalArgumentException("Valor no puede ser nulo" + "vacio");
        }
        
        //Primer nodo insertado se convierte en la raiz
        if (this.esArbolVacio()) {
            this.raiz = new NodoMVias<>(this.orden + 1, claveAInsertar, valorAsociado);
        return;
        }
        
        Stack<NodoMVias<K,V>> pilaDeAncestros = new Stack<>();
        NodoMVias<K, V> nodoAuxi = this.raiz;
        
        do {
            int posicionDeClaveAInsertar = super.buscarPosicionDeClave(claveAInsertar,nodoAuxi);
            if (posicionDeClaveAInsertar != POSICION_INVALIDA) { //Cuando la clave ya existe
                nodoAuxi.setValor(posicionDeClaveAInsertar, valorAsociado);
                nodoAuxi = NodoMVias.nodoVacio();
            } else if (nodoAuxi.esHoja()) {
                //El nodoAuxi es hoja y la clave no esta en el nodo
                    super.insertarClaveYValorOrdenado(nodoAuxi, claveAInsertar, valorAsociado);
                    if (nodoAuxi.nroDeClavesNoVacias() > this.nroMaxDeClaves) {
                        this.dividirNodo(nodoAuxi,pilaDeAncestros);
                    }
                    nodoAuxi = NodoMVias.nodoVacio();
            } else {
                //El nodoAuxi no es una hoja y ya sabemos que la clave no esta en el nodo
                int posicionPorDondeBajar = this.buscarPosicionPorDondeBajar(nodoAuxi, claveAInsertar);
                pilaDeAncestros.push(nodoAuxi);
                nodoAuxi = nodoAuxi.getHijo(posicionPorDondeBajar);  
            }
        }while (!NodoMVias.esNodoVacio(nodoAuxi));
    }

       
//    public V eliminar (K claveAEliminar){
//        if (claveAEliminar == null) {
//            throw new IllegalArgumentException("Clave no puede ser nula" + "vacia");
//        }
//        
//        Stack<NodoMVias<K,V>> pilaDeAncestros = new Stack<>();
//        NodoMVias<K,V> nodoDeLaClaveAEliminar = this.buscarNodoDeLaClave(claveAEliminar,pilaDeAncestros);
//        // buscarNodoDeLaClave --> metodo a implementar
//        if (NodoMVias.esNodoVacio(nodoDeLaClaveAEliminar)) {
//            return null;  
//        }
//        int posicionDeClaveAEliminar = super.buscarPosicionDeClave( claveAEliminar,nodoDeLaClaveAEliminar);
//        V valorARetornar = nodoDeLaClaveAEliminar.getValor(posicionDeClaveAEliminar);
//        if (nodoDeLaClaveAEliminar.esHoja()) {
//            super.eliminarClaveDeNodoDePosicion(nodoDeLaClaveAEliminar,posicionDeClaveAEliminar);
//            if (nodoDeLaClaveAEliminar.nroDeClavesNoVacias()<this.nroMimDeClaves) {
//                if (pilaDeAncestros.isEmpty()) {
//                    if (nodoDeLaClaveAEliminar.nroDeClavesNoVacias()==0) {
//                        super.vaciar();
//                    }
//                }else{
//                 prestarOFusionar(nodoDeLaClaveAEliminar,pilaDeAncestros); //implemetar este  metodo   
//                }        
//            }
//        }else{
//            pilaDeAncestros.push(nodoDeLaClaveAEliminar);
//            NodoMVias<K,V> nodoDelPredecesor = this.obtenerNodoDelPredecesor(
//                        pilaDeAncestros,nodoDeLaClaveAEliminar.getHijo(
//                                posicionDeClaveAEliminar));
//            K claveDelPredecesor = nodoDelPredecesor.getClave(
//                    nodoDelPredecesor.nroDeClavesNoVacias()-1);
//            V valorDelPredecesor = nodoDelPredecesor.getValor(
//                    nodoDelPredecesor.nroDeClavesNoVacias()-1);
//            super.eliminarClaveDelNodoDePosicion(nodoDelPredecesor,nodoDelPredecesor.nroDeClavesNoVacias()-1);
//            nodoDeLaClaveAEliminar.setClave(posicionDeClaveAEliminar, claveDelPredecesor);
//            nodoDeLaClaveAEliminar.setValor(posicionDeClaveAEliminar, valorDelPredecesor);
//            prestarOFusionar(pilaDeAncestros,nodoDelPredecesor);
//            
//            
//        }
//        return valorARetornar;
//            
//    }

    private void dividirNodo(NodoMVias<K, V> nodoAuxi, Stack<NodoMVias<K, V>> pilaDeAncestros) {
        int posClaveMediana = this.nroMimDeClaves; //1
        K claveMediana = nodoAuxi.getClave(posClaveMediana);
        V valorMediano = nodoAuxi.getValor(posClaveMediana);

        NodoMVias<K, V> nuevoNodoDerecho = new NodoMVias<>(this.orden + 1);
        for (int i = posClaveMediana + 1; i <= this.nroMaxDeClaves; i++) {
            nuevoNodoDerecho.setClave(i - posClaveMediana - 1, nodoAuxi.getClave(i));
            nuevoNodoDerecho.setValor(i - posClaveMediana - 1, nodoAuxi.getValor(i));
            nuevoNodoDerecho.setHijo(i - posClaveMediana - 1, nodoAuxi.getHijo(i));
        }
        int pos = nuevoNodoDerecho.nroDeClavesNoVacias();
        nuevoNodoDerecho.setHijo(pos, nodoAuxi.getHijo(this.orden));

        nodoAuxi.setClave(posClaveMediana, null);
        nodoAuxi.setValor(posClaveMediana, null);
        for (int i = posClaveMediana + 1; i <= this.nroMaxDeClaves; i++) {
            nodoAuxi.setClave(i, null);
            nodoAuxi.setValor(i, null);
            nodoAuxi.setHijo(i, null);
        }
        nodoAuxi.setHijo(this.orden, null);

        if (pilaDeAncestros.isEmpty()) {
            NodoMVias<K, V> nuevaRaiz = new NodoMVias<>(this.orden + 1, claveMediana, valorMediano);
            nuevaRaiz.setHijo(0, nodoAuxi);
            nuevaRaiz.setHijo(1, nuevoNodoDerecho);
            this.raiz = nuevaRaiz;
        } else {
            NodoMVias<K, V> nodoPadre = pilaDeAncestros.pop();
            super.insertarClaveYValorOrdenado(nodoPadre, claveMediana, valorMediano);
            int posicionClaveMediana = this.buscarPosicionDeClave(claveMediana,nodoPadre);
            nodoPadre.setHijo(posicionClaveMediana + 1, nuevoNodoDerecho);

            if (nodoPadre.nroDeClavesNoVacias() > this.nroMaxDeClaves) {
                this.dividirNodo(nodoPadre, pilaDeAncestros);
            }
        }   
    }
    
    
}

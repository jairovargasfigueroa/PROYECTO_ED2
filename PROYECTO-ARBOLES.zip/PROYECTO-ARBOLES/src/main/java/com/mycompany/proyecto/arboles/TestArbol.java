/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.proyecto.arboles;

import Arboles.AVL;
import Arboles.ArbolB;
import Arboles.ArbolBinarioBusqueda;
import Arboles.ArbolMViasBusqueda;
import Arboles.IArbolBusqueda;
import Excepciones.OrdenInvalidoExcepcion;
import java.util.Scanner;



/**
 *
 * @author jairo
 */
public class TestArbol {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws OrdenInvalidoExcepcion{ 
        IArbolBusqueda <Integer,String> arbolPrueba;
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Elija el tipo de Arbol(ABB,AVL,AMB,AB):");
        
        String tipoArbol = entrada.next();
        
        switch (tipoArbol) {
            case "ABB":
                arbolPrueba = new ArbolBinarioBusqueda<Integer, String>();
                break;
            case "AVL":
                arbolPrueba = new AVL<>();
                break; 
            case "AMB":
                arbolPrueba = new ArbolMViasBusqueda<Integer, String>(4);
                break; 
            case "AB":
                arbolPrueba = new ArbolB<Integer, String>(4);
                break;     
            default:
                System.out.println("Tipo de Arbol invalido. usando AVL");
                arbolPrueba = new AVL<>();
                break;
        }
        
        arbolPrueba.insertar(20, "azul");
        arbolPrueba.insertar(18, "rojo");
        arbolPrueba.insertar(25, "amarillo");       
        arbolPrueba.insertar(10, "blanco");
        arbolPrueba.insertar(19, "negro");
        arbolPrueba.insertar(22, "22");
        arbolPrueba.insertar(30, "verde");
        arbolPrueba.insertar(9, "Jairo");
        arbolPrueba.insertar(12, "Jairo");
        arbolPrueba.insertar(24, "dorado");
        arbolPrueba.insertar(29, "negro");
        arbolPrueba.insertar(33, "negro");      
        arbolPrueba.insertar(32, "negro");
        arbolPrueba.insertar(60, "negro");
        arbolPrueba.insertar(65, "65");
//        System.out.println("*****************************************************");
        System.out.println("RECORRIDO POR NIVELES: " + arbolPrueba.recorridoEnInOrden());
        System.out.println("altura = " + arbolPrueba.altura());
//        System.out.println("nroDeHijosVaciosEsUnNivel = " + arbolPrueba.nroDeHijosEnUnNivelN(1));
//        System.out.println("nrooDeHojas = "+ arbolPrueba.nroDeHojas());
//        System.out.println("nrooDeHojas = "+ arbolPrueba.nroDeHojasRec());
//        System.out.println("nrooDeHojasEnUnNivel = "+ arbolPrueba.nroDeHojasEnUnNivel(3));
//        System.out.println("nrooDeHojasEnUnNivelRec = "+ arbolPrueba.nroDeHojasEnUnNivelRec(3));
//        System.out.println("nrooDeHojasAntesDeUnNivelRec = "+ arbolPrueba.nroDeHojasAntesDeUnNivelRec(4));
//        System.out.println("nrooDeHojasDespuesDeUnNivelRec = "+ arbolPrueba.nroDeHojasDespuesDeUnNivelRec(2));
//        arbolPrueba.insertarRecursivo(33, "negro");
//         System.out.println("RECORRIDO POR NIVELES: " + arbolPrueba.recorridoPorNiveles());
//         arbolPrueba.insertarRecursivo(10, "negro");
//         System.out.println("RECORRIDO POR NIVELES: " + arbolPrueba.recorridoPorNiveles());
//        System.out.println("nroNodosCompletos = "+ arbolPrueba.tieneNodosCompletosEnUnNivel(2));
//        System.out.println("size = " + arbolPrueba.size());
//        System.out.println("sizeRec = " + arbolPrueba.sizeRec());
//        System.out.println("nivel = " + arbolPrueba.nivel());
//        System.out.println("x = " + arbolPrueba.nroClavesVaciasHastaUnNivelN(3));
//        System.out.println("nroDeHojas = " + arbolPrueba.nroDeHojasEnElArbol());
//        System.out.println("nroDeHojasEsUnNivel = " + arbolPrueba.nroDeHojasAPartirDeUnNivel(1));
//          arbolPrueba.recorridoEnPosOrden();
//        System.out.println("Valor = " + arbolPrueba.eliminarI(20));
//        System.out.println("nroDePadres" + arbolPrueba.nroDePadres());
//        System.out.println("siSonPares = " + arbolPrueba.siTodasLasClavesSonPares());
//        System.out.println("RECORRIDO POR NIVELES: " + arbolPrueba.recorridoPorNiveles());
//        System.out.println("EsAVL = " + arbolPrueba.esAVL());
//        System.out.println("EsAVLDesdeUnNivel = " + arbolPrueba.esAVLDesdeUnNivel(2));
//            System.out.println("nroDeNodosCompletos = " + arbolPrueba.tieneNodosCompletosEnUnNivel(3));
//          String val = arbolPrueba.eliminar(22);
//          System.out.println("Elim: " + val);
        
//        System.out.println("NroDeHojasHastaUnNivelN = " + arbolPrueba.nroDeHojasEnUnNivelRec(4));
//        System.out.println("AlturaI = " + arbolPrueba.alturaI());
//        System.out.println("NivelI = " + arbolPrueba.nivelI());
//        System.out.println("Minimo=" + arbolPrueba.minimo());
//        System.out.println("buscar="+arbolPrueba.buscarRec(20));
//        System.out.println("buscar="+arbolPrueba.buscarRec(18));
//        System.out.println("buscar="+arbolPrueba.buscarRec(25));
//        System.out.println("nroDeHojas = " + arbolPrueba.nroDeHojasRec());
//        System.out.println("SizeRec = " + arbolPrueba.sizeRec());
//        System.out.println("Size = " + arbolPrueba.size());
//        System.out.println("nroDeHojasEnUnNivel = " + arbolPrueba.nroDeHojasEnUnNiel(2));
        
//        System.out.println("size1=" + arbolPrueba.size());
//        System.out.println("ValorEliminado ="+ arbolPrueba.eliminar(100));
//        System.out.println("RecorridoNiveles2"+arbolPrueba.recorridoPorNiveles());
//        System.out.println("altura=" + arbolPrueba.altura());
//        System.out.println("nivel=" + arbolPrueba.nivel());
//        System.out.println("size=" + arbolPrueba.size());
//       
//        
//        ArbolBinarioBusqueda<Integer,String> arbolPruebaBinario=((ArbolBinarioBusqueda<Integer,String>)arbolPrueba);

        
//        arbolPruebaBinario.insertarRecursivo(58, "hola");
//        arbolPruebaBinario.insertarRecursivo(43, "hola");
//        arbolPruebaBinario.insertarRecursivo(80, "mundo");
//        arbolPruebaBinario.insertarRecursivo(20, "mundo");
//        arbolPruebaBinario.insertarRecursivo(50, "mundo");
//        arbolPruebaBinario.insertarRecursivo(70, "mundo");
//        arbolPruebaBinario.insertarRecursivo(100, "mundo");
//        arbolPruebaBinario.insertarRecursivo(22, "Jairo");
//        arbolPruebaBinario.insertarRecursivo(48, "mundo");
//        arbolPruebaBinario.insertarRecursivo(60, "mundo");
//        arbolPruebaBinario.insertarRecursivo(94, "mundo");
//        arbolPruebaBinario.insertarRecursivo(200, "mundo");
//        arbolPruebaBinario.insertarRecursivo(49, "mundo");
//        
//        System.out.println(arbolPrueba);
//        
//        
//        System.out.println("RecorridoNiveles"+arbolPrueba.recorridoPorNiveles());
//        System.out.println("RecorridoPosOrden"+arbolPrueba.recorridoEnPosOrden());
//        System.out.println("RecorridoPreOrden   "+ arbolPruebaBinario.recorridoEnPreOrden());
//        System.out.println("RecorridoInOrdenRec   "+ arbolPruebaBinario.recorridoEnPreOrdenRec());
//        
//        System.out.println("valor= " + arbolPrueba.buscar(10));
//        System.out.println("size= " + arbolPrueba.size());
//        System.out.println("Altura= " + arbolPrueba.altura());
//        System.out.println("Nivel= " + arbolPrueba.nivel());
//        System.out.println("Eliminado= " + arbolPrueba.eliminar(22));
//        System.out.println("RecorridoPreEliminando   "+ arbolPruebaBinario.recorridoEnPreOrdenRec());
//        
        
//        ArbolMViasBusqueda<Integer,String> arbolPruebaMVias=((ArbolMViasBusqueda<Integer,String>)arbolPrueba);
//        System.out.println("RecorridoPorNiveles = " + arbolPruebaMVias.recorridoPorNiveles());
//        System.out.println("x=" + arbolPruebaMVias.nroClavesVaciasEnElArbol(4));
    
    }
    
}
